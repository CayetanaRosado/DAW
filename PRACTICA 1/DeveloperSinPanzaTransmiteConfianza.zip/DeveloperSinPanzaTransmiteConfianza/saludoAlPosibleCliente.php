<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>

        <h1>BIENVENIDO A DEVELOPER SIN PANZA TRANSMITE CONFIANZA</h1>
        <h2>Resumen de datos</h2>
        <?php
        $Sexo = $_GET["Sexo"];
        $Altura = $_GET["Altura"];
        $Peso = $_GET["Peso"];

        echo "Sexo: $Sexo </br> Altura en cm: $Altura </br> Peso en kg: $Peso";
        ?>

        <h2>Índice de Masa Corporal</h2>
        <?php
        $imc = $alturaEnMetros = $Altura / 100;
        $imc = $Peso / ($alturaEnMetros * $alturaEnMetros);

        $imc_redondeado = round($imc, 1);
        echo "Tu índice de masa corporal (IMC) es: $imc_redondeado";
        ?>

        <h2>Interpretación del IMC</h2>

        <?php
        if ($imc_redondeado < 18) {
            echo "Tu peso es inferior al saludable. Te recomendamos seguir
              nuestro programa para ganar masa muscular y mejorar tu salud.";
        } else if ($imc_redondeado >= 18 & $imc_redondeado < 20) {
            echo "Tu peso se encuentra en la banda más baja del peso saludable.
            Te recomendamos seguir nuestro programa para ganar masa muscular y
            mejorar tu salud.";
        } else if ($imc_redondeado >= 20 & $imc_redondeado < 23) {
            echo "Enhorabuena. Tu peso es el óptimo. Te recomendamos seguir
            nuestro programa para ganar masa muscular, perfeccionar algunas zonas de tu
            cuerpo y mejorar tu salud.";
        } else if ($imc_redondeado >= 23 & $imc_redondeado < 25) {
            echo "Tu peso se encuentra en la banda alta del peso normal. Te
            recomendamos seguir nuestro programa para reducir tu peso, ganar masa
            muscular, perfeccionar algunas zonas de tu cuerpo y mejorar tu salud.";
        } else if ($imc_redondeado >= 25 & $imc_redondeado < 28) {
            echo "Tienes exceso de peso. Reducir tu peso es beneficioso para tu
            salud y te permitirá encontrarte más ágil y conseguir un físico más juvenil.";
        } else if ($imc_redondeado >= 28 & $imc_redondeado < 30) {
            echo "Tienes exceso de peso. Reducir tu peso es necesario para tu
            salud y te permitirá encontrarte más ágil y mejorar tu físico. Es el momento de
            tomar medidas.";
        } else {
            echo "Tienes peso muy superior a lo aconsejable. Reducir tu peso es
            necesario para tu salud y te permitirá encontrarte más ágil y mejorar tu físico. Es
            posible que hayas estado ganando peso de forma continuada últimamente. Es el
            momento de tomar medidas.";
        }
        ?>

        <h2>Recomendaciones generales para la pérdida de peso</h2>

        <p>Dependiendo de los objetivos del usuario, incluir un texto con recomendaciones generales para
            la pérdida de peso basado en los kilos que desea perder:</p>
        <ul>
            <li><b> Menos de 5 kg:<br></b>
            "Puedes perder el peso que deseas en un mes aproximadamente siempre que tu
            cumplimiento de la dieta esté por encima de un 90%. Cambiar tus hábitos de forma
            permanente te llevará unos 3-4 meses más."</li>
        <li><b> De 5 a 10 kg:<br></b>
            "Puedes perder el peso que deseas en 2-3 meses aproximadamente siempre que tu
            cumplimiento de la dieta esté por encima de un 90%. Cambiar tus hábitos de forma
            permanente te llevará unos 3-4 meses más."</li>
        <li><b> De 11 a 15 kg:<br></b>
            "Puedes perder el peso que deseas en 4-5 meses aproximadamente siempre que tu
            cumplimiento de la dieta esté por encima de un 90%. Cambiar tus hábitos de forma
            permanente te llevará unos 3-4 meses más."</li>
        <li><b> De 16 a 20 kg:<br></b>
            "Puedes perder el peso que deseas en 6-7 meses aproximadamente siempre que tu
            cumplimiento de la dieta esté por encima de un 90%. En este tiempo habrás adquirido
            hábitos más saludables que te permitirán mantener tu nuevo peso."</li>
        <li><b> De 20 a 25 kg:<br></b>
            "Puedes perder el peso que deseas en un año aproximadamente siempre que tu
            cumplimiento de la dieta esté por encima de un 85%. En este tiempo habrás adquirido
            hábitos más saludables que te permitirán mantener tu nuevo peso."</li>
        <li><b> Más de 25 kg:<br></b>
            "Puedes perder el peso que deseas en un plazo de entre 1-2 años aproximadamente
            siempre que tu cumplimiento de la dieta esté por encima de un 80%. En este tiempo
            habrás adquirido hábitos más saludables que te permitirán mantener tu nuevo peso."</li>
        </ul>

        <H2><i>"Toma el control de tu salud ahora. Cada paso que des hacia un estilo de vida saludable
                marcará la diferencia."</i></H2>

    </body>
</html>




