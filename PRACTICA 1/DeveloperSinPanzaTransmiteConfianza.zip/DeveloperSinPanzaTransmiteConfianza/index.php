<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>

        <h1>Formulario de Registro</h1>
        <form action="saludoAlPosibleCliente.php" method="get">


            <p><label for="Peso">Peso (kg): </label>
                <input type="number" name="Peso" id="Peso"></p

            <p><label for="Altura">Altura (cm):</label>
                <input type="number" name="Altura" id="Altura"></p>

            <p><label for="FechaDeNacimiento">Fecha de Nacimiento:</label>
                <input type="date" name="FechaDeNacimiento" id="FechaDeNacimiento"></p>

            <p><label for="Email">Email:</label>
                <input type="email" name="Email" id="Email"></p>

            <p><label for="Sexo">Sexo:</label>
                <select name="Sexo" id="Sexo">
                     <option value="" disabled selected>Selecciona tu sexo</option>
                    <option value="Hombre">Hombre</option>
                    <option value="Mujer">Mujer</option>
                    <option value="Mujer embarazada">Mujer embarazada</option>
                </select>
                
            <p><label for="actividad_fisica">Actividad Física:</label>
                <select id="actividad_fisica" name="actividad_fisica">
                    <option value="" disabled selected>Selecciona tu nivel de actividad</option>
                    <option value="movilidad_casi_nula">Movilidad casi nula</option>
                    <option value="movilidad_muy_reducida">Movilidad muy reducida</option>
                    <option value="normal">Normal</option>
                    <option value="activa">Activa (1,5 a 2,5 h/sem.)</option>
                    <option value="muy_activa">Muy activa (>2,5 h/sem.)</option>
                    <option value="deportista">Deportista</option>
                </select></p>

            <p> <label for="objetivo">Mi objetivo:</label>
                <select id="objetivo" name="objetivo">
                    <option value="" disabled selected>Selecciona tu objetivo</option>
                    <option value="perder_peso">Perder peso</option>
                    <option value="mejorar_salud">Mejorar mi salud</option>
                    <option value="ganar_musculo">Ganar peso/músculo</option>
                </select></p>

            <p><input type="submit" value="enviar"></p>
        </form>
    </body>
</html>
